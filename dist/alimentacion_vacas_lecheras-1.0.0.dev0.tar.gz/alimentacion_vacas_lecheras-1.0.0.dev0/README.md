"# nutricion-vacas-lecheras" 

calculo de los requerimientos de energía, proteína, vitaminas, minerales y otros nutrientes para diferentes etapas para vacas lecheras.

el paquete está en desarrollo y que algunas funcionalidades pueden no estar completamente implementadas